 ------------------------------------
| Assembly.PromoteNTA.dll XML Readme |
| �2013 Adam Smith-Platts            |
 ------------------------------------

In this directory you shall find an XML file with the same name as the DLL file that you have downloaded.
The reason for this XML is so that developers using this resource can utilise Visual Studio IntelliSence 
to see the method summaries and parameter explanations. Unfortunately a [Visual Studio] compiled DLL does not
get the IntelliSence data compiled, and there is no way to compile and reference the XML; so a seperate file 
is needed.

To use it, just copy the XML to the same location as the DLL (in your project) and Visual Studio will do the 
rest. When you go to compile/release, just remove the XML ... or don't! It's not needed outside of Visual
Studio IntelliSence so if you don't want it in your compiled app, don't include it :)

Any issues, bugs or just general feedback feel free to hit me up on Twitter (@SmithPlatts) or via 
email (StufftheBox@me.com).
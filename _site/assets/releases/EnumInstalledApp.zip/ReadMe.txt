################################################################################################################
#                                                                                                              #
#  EnumInstalledApp is a command line tool that searches the machines Uninstall registry key for an installed  #
#  application and prints the key name, display name and display version of each [partial] match.              #
#                                                                                                              #
#  Current version: 1.0.73.203                                                                                 #
#                                                                                                              #
################################################################################################################

###############
#   Licence   #
###############

Copyright � 2013 Adam Smith-Platts (stuffthebox@me.com)
This software is provided free for use and distribution. Do not sell or receive donation.

###############
#    Usage    #
###############

ENUMINSTALLEDAPP -Find:"string"[,"string","string",...] [-CS] [-Host:[RemoteHost]] [-NH] [-Scope:[Contains|Exact|StartsWith]] [-WOW6432[:Only]]

  -Find:"string"[,"string","string",...]

            The string that you want to find within the installed applications display name.
            Multiple strings can be specified and will be searched independently.

  -CS       Optional: Force the use of case sensitivity when searching for the specified string/s.

  -Host:[RemoteHost]

            Optional: The remote hosts' machine name to connect to to perform the search.
            By default, the local machine is searched.
            N.B. If executing on a 32-bit system but the remote host is a 64-bit system, only the remote hosts' 32-bit registry is searched.

  -NH       Optional: Prevent the header text from displaying at execution time.

  -Scope:[Contains|Exact|StartsWith]

            Optional: Determines the scope of the how the string is matched:
            - Contains:   value contains string
            - Exact:      value is equal to string
            - StartsWith: value starts with string
            By default, Contains is assumed.

  -WOW6432[:Only]

            Optional: If searching on a 64-bit Windows machine, search the 32-bit registry as well as the native (64-bit) registry. If appended with :Only, only the 32-bit registry is searched.
            N.B. This setting has no effect on 32-bit Windows systems.
